Please install dependencies in all 3 folders (root, backend and frontend) and run npm run dev in root folder
